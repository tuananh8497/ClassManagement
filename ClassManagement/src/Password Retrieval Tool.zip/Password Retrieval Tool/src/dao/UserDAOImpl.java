/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.User;
import utils.DBUtils;

/**
 *
 * @author Minh Duc
 */
public class UserDAOImpl implements UserDAO {

    private Connection con = null;
    private Statement statement = null;
    private PreparedStatement prepareStatement = null;

    @Override
    public boolean updateUser(String username, String password, int id, String hash) {
        try {
            con = DBUtils.getConnection(username, password);
            String query = "UPDATE USERS SET hashPassword = '" + hash + "' WHERE userId = ?";
            prepareStatement = con.prepareStatement(query);
            prepareStatement.setInt(1, id);
            prepareStatement.executeUpdate();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(con, statement, prepareStatement);
        }
        return false;
    }

    @Override
    public List<User> getAllUser(String username, String password) {
        try {
            con = DBUtils.getConnection(username, password);
            String query = "SELECT * FROM USERS";
            statement = con.createStatement();
            ResultSet rs = statement.executeQuery(query);
            List<User> lstUser = new ArrayList<User>();
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt(1));
                user.setHashPassword(rs.getString(2));
                user.setUserName(rs.getString(3));
                lstUser.add(user);
            }

            return lstUser;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(con, statement, prepareStatement);
        }

        return null;
    }

}
