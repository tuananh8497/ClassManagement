package dao;

import java.util.List;
import model.User;

public interface UserDAO {
    boolean updateUser(String username, String password, int id, String hash);

    List<User> getAllUser(String username, String password);
}
